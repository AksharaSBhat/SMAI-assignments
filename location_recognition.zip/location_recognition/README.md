# RegionID prediction
I have used Efficient net B0 pretrained CNN and finetuned it by adding 2 hidden layers of head( with 512 and 256 neurons). I train it for 30 epochs and drop the Learning rate by 10x every 10 epochs. I use early stopping and dropout. In addition to all these, after training it once for 30 epochs, I train it again, this time loading the weights from the earlier train but randomise the weights a little bit. I Applied random rotations (±5°), horizontal flips, color jitter (brightness/contrast ±0.1), and resize (256×256) during training.

# Direction prediction
I have used Efficient net B0 pretrained CNN and finetuned it by adding 2 hidden layers of head( with 512 and 256 neurons). I train it for 50 epochs. I give region IDs as prior to the model to help it better predict the angle according to the region. I generate new csv files from the given files to have priors and then use them. I Applied random rotations (±5°), horizontal flips, color jitter (brightness/contrast ±0.1), and resize (256×256) during training.

# Latitude and longitude prediction
I have used Efficient net B0 pretrained CNN and finetuned it by adding 2 hidden layers of head( with 512 and 256 neurons). I train it for 30 epochs along with early stopping and dropout. I also give the predictions of region ID using my already trained model as prior. I Applied random rotations (±5°), horizontal flips, color jitter (brightness/contrast ±0.1), and resize (256×256) during training. I also removed outliers and cleaned the data and plotted the same. Another innovation is I initialize the model to predict the mean latitude and longitude and then fine tune it so the model can converge fast. I use less batch size here to avoid memory scarcity issues.

# Model weights
https://drive.google.com/drive/folders/1cVkktlpdRnuIP4BatP0BjbDaixgPDoP-?usp=sharing